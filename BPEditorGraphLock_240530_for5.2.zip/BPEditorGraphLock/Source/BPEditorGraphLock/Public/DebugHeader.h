// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

/*Debug macros*/
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

#define Sleep(Frame) std::this_thread::sleep_for(std::chrono::milliseconds(Frame))

#define NewThread(Execute) std::thread([&]() {Execute}).detach()

/*Debug functions*/
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
}
