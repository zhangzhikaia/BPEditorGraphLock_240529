// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"

#include "Modules/ModuleManager.h"
#include "BlueprintEditor.h"

class FBPEditorGraphLockModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:

	void InitBPEditorExtender();

	void FinishBPEditorExtender();

	void HandleRegisterBlueprintEditorTab(FWorkflowAllowedTabSet& WorkflowAllowedTabSet,FName ModeName, TSharedPtr<FBlueprintEditor> BlueprintEditor);

public:
	
	void AddUEdGraphNode_Lock(UEdGraph* Graph);
	
private:
	
	FDelegateHandle OnRegisterTabsForEditorHandle;
};
