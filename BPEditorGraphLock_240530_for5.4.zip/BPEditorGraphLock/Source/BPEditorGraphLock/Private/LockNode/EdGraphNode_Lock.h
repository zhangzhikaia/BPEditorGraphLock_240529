// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"

#include "SGraphTitleBar.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraphNode_Lock.generated.h"

UCLASS()
class BPEDITORGRAPHLOCK_API UEdGraphNode_Lock : public UEdGraphNode
{
	GENERATED_BODY()

private:

	struct HackSGraphTitleBar : SGraphTitleBar
	{
		TSharedPtr<SScrollBox> GetBreadcrumbTrailScrollBox(){return BreadcrumbTrailScrollBox;}
	};
	
	struct HackSScrollBox : SScrollBox
	{
		TSharedPtr<SScrollPanel> GetScrollPanel(){return ScrollPanel;}
	};
	
	UEdGraphNode_Lock();
	~UEdGraphNode_Lock();
	
public:
	
	TSharedPtr<SGraphNode> GetWidget() { return Widget.Pin(); }
	
	void SetWidget(TSharedPtr<SGraphNode> InWidget) { Widget = InWidget; }
	
private:
	// UEdGraphNode implementation
	virtual bool CanDuplicateNode() const override { return false; }  
	virtual bool CanUserDeleteNode() const override { return false; }  
	virtual bool CanJumpToDefinition() const override { return false; }  
	// End UEdGraphNode implementation

	/*Create SNodeStyle_Lock*/
	virtual TSharedPtr<SGraphNode> CreateVisualWidget() override;

	/*For titlebar*/
	void ConstructButton(TSharedPtr<SGraphEditor> GraphEditor);

public:
	/*Basically called during new one, but cannot be called during construction, which will cause a crash for unknown reasons.*/
	void OnActiveTabChangedBindOnce();
	
private:
	/*SNodeStyle_Lock's instance*/
	TWeakPtr<SGraphNode> Widget;

private:
	bool IsOnActiveTabChangedBinded;

	TSharedPtr<SScrollBox> TitleScrollBox;

	TSharedPtr<SScrollPanel> ScrollPanelInBox;
	
	TSharedPtr<SCheckBox> LockCheckBox;

	FDelegateHandle ActiveTabChangedHandle;
	
};
